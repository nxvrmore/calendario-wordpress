<?php
/*
Plugin Name: Calendario Plugin
Description: Un plugin para mostrar un calendario con 31 días y permitir añadir texto en cada día.
Version: 1.0
Author: BIERZOSEO
*/

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Registrar el shortcode
function calendario_shortcode() {
    ob_start();
    mostrar_calendario();
    return ob_get_clean();
}
add_shortcode('calendario', 'calendario_shortcode');

// Función para mostrar el calendario
function mostrar_calendario() {
    // Obtener los textos guardados
    $textos = get_option('calendario_textos', array());

    // Estructura del calendario
    echo '<div class="calendario-container">';
    for ($i = 1; $i <= 31; $i++) {
        $texto = isset($textos[$i]) ? esc_html($textos[$i]) : '';
        $tieneTexto = !empty($texto) ? 'tiene-texto' : ''; // Clase para casillas con texto
        echo '<div class="calendario-dia ' . $tieneTexto . '" data-texto="' . esc_attr($texto) . '">';
        echo '<span class="dia-numero">' . $i . '</span>';
        echo '<div class="dia-texto">' . $texto . '</div>'; // Texto visible en escritorio
        echo '</div>';
    }
    echo '</div>';

    // Popup para mostrar el texto (solo en móvil)
    echo '
    <div id="calendario-popup" class="calendario-popup">
        <div class="calendario-popup-contenido">
            <span class="calendario-popup-cerrar">&times;</span>
            <p id="calendario-popup-texto"></p>
        </div>
    </div>
    ';
}

// Añadir estilos CSS
function calendario_estilos() {
    echo '
    <style>
        .calendario-container {
            display: grid;
            grid-template-columns: repeat(7, 1fr); /* 7 columnas */
            gap: 10px;
            padding: 20px;
            background-color: transparent;
            border-radius: 10px;
            width: 100%;
        }
        .calendario-dia {
            box-sizing: border-box;
            border: 1px solid #e0e0e0;
            padding: 10px;
            text-align: center;
            min-height: 100px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: flex-start;
            background-color: #957dad3f;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            position: relative;
        }
        .calendario-dia:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .dia-numero {
            font-size: 1.2em;
            font-weight: bold;
            color: #957dad;
        }
        .dia-texto {
            font-size: 0.9em;
            color: #333;
            text-align: left;
            width: 100%;
            margin-top: 5px;
        }
        .calendario-dia.tiene-texto::after {
            content: "";
            position: absolute;
            top: 5px;
            right: 5px;
            width: 10px;
            height: 10px;
            background-color: green;
            border-radius: 50%;
        }
        .calendario-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .calendario-popup-contenido {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 90%;
            width: 400px;
            position: relative;
        }
        .calendario-popup-cerrar {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 1.5em;
            cursor: pointer;
            color: #333;
        }
        .calendario-popup-cerrar:hover {
            color: #957dad;
        }
        /* Estilos para móvil */
        @media (max-width: 768px) {
            .calendario-container {
                grid-template-columns: repeat(7, 80px); /* Tamaño fijo para móvil */
                overflow-x: auto; /* Scroll horizontal si es necesario */
                padding: 10px;
            }
            .calendario-dia {
                min-height: 80px; /* Tamaño reducido para móvil */
            }
            .dia-texto {
                display: none; /* Ocultar texto en móvil */
            }
        }
    </style>
    ';
}
add_action('wp_head', 'calendario_estilos');

// Añadir scripts para el popup (solo en móvil)
function calendario_scripts() {
    echo '
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Abrir popup al hacer clic en un día (solo en móvil)
            if (window.innerWidth <= 768) {
                document.querySelectorAll(".calendario-dia").forEach(function(dia) {
                    dia.addEventListener("click", function() {
                        const texto = this.getAttribute("data-texto");
                        if (texto) {
                            document.getElementById("calendario-popup-texto").textContent = texto;
                            document.getElementById("calendario-popup").style.display = "flex";
                        }
                    });
                });

                // Cerrar popup
                document.querySelector(".calendario-popup-cerrar").addEventListener("click", function() {
                    document.getElementById("calendario-popup").style.display = "none";
                });

                // Cerrar popup al hacer clic fuera del contenido
                document.getElementById("calendario-popup").addEventListener("click", function(event) {
                    if (event.target === this) {
                        this.style.display = "none";
                    }
                });
            }
        });
    </script>
    ';
}
add_action('wp_footer', 'calendario_scripts');

// Añadir menú de administración
function calendario_menu_admin() {
    add_menu_page(
        'Calendario',
        'Calendario',
        'manage_options',
        'calendario-admin',
        'calendario_admin_page',
        'dashicons-calendar',
        6
    );
}
add_action('admin_menu', 'calendario_menu_admin');

// Página de administración
function calendario_admin_page() {
    // Guardar los textos si se ha enviado el formulario
    if (isset($_POST['calendario_textos']) && check_admin_referer('guardar_calendario_textos', 'calendario_nonce')) {
        $textos = array();
        foreach ($_POST['calendario_textos'] as $dia => $texto) {
            $textos[intval($dia)] = sanitize_text_field($texto);
        }
        update_option('calendario_textos', $textos);
        echo '<div class="updated"><p>Textos guardados correctamente.</p></div>';
    }

    // Obtener los textos guardados
    $textos = get_option('calendario_textos', array());

    // Formulario de administración
    echo '<div class="wrap">';
    echo '<h1>Configuración del Calendario</h1>';
    echo '<form method="post" action="">';
    wp_nonce_field('guardar_calendario_textos', 'calendario_nonce');
    for ($i = 1; $i <= 31; $i++) {
        echo '<div>';
        echo '<label for="calendario_textos[' . $i . ']">Día ' . $i . ':</label>';
        echo '<input type="text" id="calendario_textos[' . $i . ']" name="calendario_textos[' . $i . ']" value="' . (isset($textos[$i]) ? esc_attr($textos[$i]) : '') . '" style="width: 300px; margin-bottom: 10px;">';
        echo '</div>';
    }
    echo '<input type="submit" class="button-primary" value="Guardar">';
    echo '</form>';
    echo '</div>';
}